import Image from "next/image"
import ShineBorder from "@/components/ui/shine-border"

interface TestimonialCardProps {
  name: string
  image: string
}

export function TestimonialCard({ name, image }: TestimonialCardProps) {
  return (
    <ShineBorder className="relative overflow-hidden rounded-xl h-[300px] group">
      <Image
        src={image}
        alt={`Testimonial by ${name}`}
        fill
        className="object-cover transition-transform duration-300 group-hover:scale-110"
      />
    </ShineBorder>
  )
}


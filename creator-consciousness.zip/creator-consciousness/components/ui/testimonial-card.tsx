import { cn } from "@/lib/utils"
import Image from "next/image"

interface TestimonialCardProps {
  name: string
  role: string
  image: string
  quote: string
}

export function TestimonialCard({ name, role, image, quote }: TestimonialCardProps) {
  return (
    <div className="relative overflow-hidden rounded-xl h-[400px] group">
      <Image
        src={image}
        alt={`Testimonial by ${name}`}
        fill
        className="object-cover transition-transform duration-300 group-hover:scale-110"
      />
      <div className="absolute inset-0 bg-black/60 transition-opacity duration-300 group-hover:opacity-75" />
      <div className="absolute inset-0 p-6 flex flex-col justify-end text-white">
        <blockquote className="text-lg font-medium mb-4 line-clamp-4">&ldquo;{quote}&rdquo;</blockquote>
        <cite className="not-italic">
          <div className="font-semibold">{name}</div>
          <div className="text-sm text-zinc-300">{role}</div>
        </cite>
      </div>
    </div>
  )
}


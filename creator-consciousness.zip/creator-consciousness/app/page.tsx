import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ArrowRight, CheckCircle, Star } from 'lucide-react'

export default function LandingPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center">
        <Link className="flex items-center justify-center" href="#">
          <Star className="h-6 w-6 text-primary" />
          <span className="ml-2 text-lg font-bold">Creator Consciousness</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#features">
            Features
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#testimonials">
            Testimonials
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#pricing">
            Pricing
          </Link>
        </nav>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-gradient-to-r from-purple-500 via-pink-500 to-red-500">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center space-y-4 text-center text-white">
              <div className="space-y-2">
                <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl/none">
                  Sculpt Your Imagination Into Reality
                </h1>
                <p className="mx-auto max-w-[700px] text-xl md:text-2xl">
                  Creative problem-solving to become the creator of your life, business, and reality
                </p>
              </div>
              <div className="w-full max-w-sm space-y-2">
                <form className="flex space-x-2">
                  <Input className="max-w-lg flex-1 bg-white text-black" placeholder="Enter your email" type="email" />
                  <Button className="bg-white text-black hover:bg-gray-200" type="submit">
                    Get Started
                  </Button>
                </form>
                <p className="text-xs">Start your journey to transformation. No credit card required.</p>
              </div>
            </div>
          </div>
        </section>
        <section id="features" className="w-full py-12 md:py-24 lg:py-32 bg-white dark:bg-zinc-900">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-center mb-12">
              Visionary Skills for Impacting the World
            </h2>
            <div className="grid gap-10 sm:grid-cols-2 md:grid-cols-3">
              <div className="flex flex-col items-center space-y-2 border-zinc-200 p-4 rounded-lg">
                <div className="p-2 bg-purple-100 rounded-full">
                  <Star className="h-6 w-6 text-purple-500" />
                </div>
                <h3 className="text-xl font-bold">Multi-Dimensional Branding</h3>
                <p className="text-zinc-500 dark:text-zinc-400 text-center">
                  Create a powerful, authentic brand that resonates across multiple platforms and audiences.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 border-zinc-200 p-4 rounded-lg">
                <div className="p-2 bg-pink-100 rounded-full">
                  <Star className="h-6 w-6 text-pink-500" />
                </div>
                <h3 className="text-xl font-bold">Unity-Based Marketing</h3>
                <p className="text-zinc-500 dark:text-zinc-400 text-center">
                  Connect with your audience on a deeper level through shared values and experiences.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 border-zinc-200 p-4 rounded-lg">
                <div className="p-2 bg-red-100 rounded-full">
                  <Star className="h-6 w-6 text-red-500" />
                </div>
                <h3 className="text-xl font-bold">Creative Problem Solving</h3>
                <p className="text-zinc-500 dark:text-zinc-400 text-center">
                  Develop innovative solutions to complex challenges in your business and life.
                </p>
              </div>
            </div>
          </div>
        </section>
        <section id="testimonials" className="w-full py-12 md:py-24 lg:py-32 bg-zinc-50 dark:bg-zinc-800">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-center mb-12">
              What Our Clients Say
            </h2>
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              <div className="flex flex-col p-6 bg-white dark:bg-zinc-900 rounded-lg shadow-lg">
                <p className="text-zinc-500 dark:text-zinc-400 mb-4">
                  "This program transformed my approach to business and life. I've never felt more aligned with my purpose."
                </p>
                <p className="font-bold">Sarah J., Entrepreneur</p>
              </div>
              <div className="flex flex-col p-6 bg-white dark:bg-zinc-900 rounded-lg shadow-lg">
                <p className="text-zinc-500 dark:text-zinc-400 mb-4">
                  "The creative problem-solving techniques I learned here have revolutionized my work. Highly recommended!"
                </p>
                <p className="font-bold">Mark T., Creative Director</p>
              </div>
              <div className="flex flex-col p-6 bg-white dark:bg-zinc-900 rounded-lg shadow-lg">
                <p className="text-zinc-500 dark:text-zinc-400 mb-4">
                  "I've achieved more in 3 months with this program than I did in years of traditional self-help."
                </p>
                <p className="font-bold">Lisa R., Life Coach</p>
              </div>
            </div>
          </div>
        </section>
        <section id="pricing" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-center mb-12">
              Transform Your Life Today
            </h2>
            <div className="grid gap-8 md:grid-cols-3">
              <div className="flex flex-col p-6 bg-white dark:bg-zinc-800 rounded-lg shadow-lg">
                <h3 className="text-2xl font-bold mb-4">Ebook/Audiobook</h3>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    Comprehensive guide
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    Audio version included
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    Lifetime access
                  </li>
                </ul>
                <p className="text-3xl font-bold mb-6">$10</p>
                <Button className="w-full">Get Started</Button>
              </div>
              <div className="flex flex-col p-6 bg-purple-100 dark:bg-purple-900 rounded-lg shadow-lg">
                <h3 className="text-2xl font-bold mb-4">Online Course</h3>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    Interactive modules
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    Practical exercises
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    Community access
                  </li>
                </ul>
                <p className="text-3xl font-bold mb-6">$100</p>
                <Button className="w-full bg-purple-600 hover:bg-purple-700">Enroll Now</Button>
              </div>
              <div className="flex flex-col p-6 bg-white dark:bg-zinc-800 rounded-lg shadow-lg">
                <h3 className="text-2xl font-bold mb-4">Personal 3-Month Program</h3>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    1-on-1 coaching
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    Customized plan
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    Weekly check-ins
                  </li>
                </ul>
                <p className="text-3xl font-bold mb-6">$1000</p>
                <Button className="w-full">Apply Now</Button>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-purple-500 via-pink-500 to-red-500">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center space-y-4 text-center text-white">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Ready to Sculpt Your Reality?
                </h2>
                <p className="mx-auto max-w-[600px] text-zinc-200 md:text-xl">
                  Join us on this transformative journey and unlock your full potential.
                </p>
              </div>
              <div className="w-full max-w-sm space-y-2">
                <form className="flex space-x-2">
                  <Input className="max-w-lg flex-1 bg-white text-black" placeholder="Enter your email" type="email" />
                  <Button className="bg-white text-black hover:bg-gray-200" type="submit">
                    Get Started
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-zinc-500 dark:text-zinc-400">© 2023 Creator Consciousness. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Terms of Service
          </Link>
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  )
}


import React from 'react'
import { cn } from "@/lib/utils"

interface ShineBorderProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode
  color?: string[]
}

export default function ShineBorder({ 
  children, 
  className, 
  color = ["#A07CFE", "#FE8FB5", "#FFBE7B"], 
  ...props 
}: ShineBorderProps) {
  return (
    <div className={cn("group relative rounded-lg p-[1px] overflow-hidden", className)} {...props}>
      <div
        className="absolute inset-0 bg-gradient-to-r opacity-0 group-hover:opacity-30 transition-opacity duration-300"
        style={{
          backgroundImage: `linear-gradient(90deg, ${color.join(', ')})`,
        }}
      />
      <div className="relative rounded-lg z-10">
        {children}
      </div>
    </div>
  )
}


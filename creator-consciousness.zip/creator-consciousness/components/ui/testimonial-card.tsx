import { NeonGradientCard } from "./neon-gradient-card"
import Image from "next/image"

interface TestimonialCardProps {
  name: string
  role: string
  image: string
  quote: string
}

export function TestimonialCard({ name, role, image, quote }: TestimonialCardProps) {
  return (
    <NeonGradientCard>
      <div className="flex flex-col items-center text-center">
        <Image
          src={image}
          alt={name}
          width={80}
          height={80}
          className="rounded-full mb-4"
        />
        <blockquote className="text-lg font-medium mb-4">&ldquo;{quote}&rdquo;</blockquote>
        <cite className="not-italic">
          <div className="font-semibold">{name}</div>
          <div className="text-sm text-zinc-400">{role}</div>
        </cite>
      </div>
    </NeonGradientCard>
  )
}


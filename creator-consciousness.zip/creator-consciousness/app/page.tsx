import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from 'lucide-react'

export default function LandingPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center">
        <Link className="flex items-center justify-center" href="#">
          {/* <MountainIcon className="h-6 w-6" /> */}
          <span className="sr-only">Creator Consciousness</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            About
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Services
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Contact
          </Link>
        </nav>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                  Automate Your Work, Amplify Your Impact
                </h1>
                <p className="mx-auto max-w-[700px] text-zinc-500 md:text-xl dark:text-zinc-400">
                  Leverage AI and automation to transform your productivity and reclaim your time
                </p>
              </div>
              <div className="space-x-4">
                <Button>Get Started</Button>
                <Button variant="outline">Learn More</Button>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-zinc-50 dark:bg-zinc-900">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-center mb-8">
              Visionary Skills for Impacting the World
            </h2>
            <div className="grid gap-10 sm:grid-cols-2 md:grid-cols-3">
              {/* <div className="flex flex-col items-center space-y-2 border-zinc-200 p-4 rounded-lg">
                <BusinessIcon className="h-12 w-12 text-zinc-900 dark:text-zinc-50" />
                <h3 className="text-xl font-bold">Business Growth with AI</h3>
                <p className="text-zinc-500 dark:text-zinc-400 text-center">
                  Leverage AI to accelerate your business growth and innovation.
                </p>
              </div> */}
              {/*  Rest of the icons are removed for brevity */}
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-center mb-8">
              Your Journey to Transformation
            </h2>
            <p className="mx-auto max-w-[700px] text-zinc-500 dark:text-zinc-400 text-center mb-12">
              Embark on a transformative journey that will reshape your approach to life, business, and personal growth.
            </p>
            <div className="flex flex-col items-center space-y-4">
              <Button className="w-full sm:w-auto">
                Start Your Journey
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-zinc-50 dark:bg-zinc-900">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-center mb-8">
              Escape the 9-5 Grind
            </h2>
            <div className="grid gap-6 lg:grid-cols-2 items-start">
              <div>
                <h3 className="text-xl font-bold mb-4">Painful Problems 9-5ers Face:</h3>
                <ul className="space-y-2 list-disc list-inside text-zinc-700 dark:text-zinc-300">
                  <li>Limited income potential and financial stress</li>
                  <li>Lack of time freedom and work-life balance</li>
                  <li>Unfulfilling work and creative stagnation</li>
                  <li>Constant overwhelm and burnout</li>
                  <li>Feeling stuck in a soul-crushing routine</li>
                  <li>Limited personal growth and skill development</li>
                  <li>Disconnection from passion and purpose</li>
                  <li>Health issues from sedentary lifestyle and stress</li>
                  <li>Minimal control over daily schedule and life direction</li>
                </ul>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="bg-white dark:bg-zinc-800 p-4 rounded-lg shadow-md">
                  <h4 className="font-bold mb-2">Multi-Dimensional Branding</h4>
                  <p className="text-sm text-zinc-600 dark:text-zinc-400">Create a powerful, authentic brand that resonates across multiple platforms and audiences.</p>
                </div>
                <div className="bg-white dark:bg-zinc-800 p-4 rounded-lg shadow-md">
                  <h4 className="font-bold mb-2">Unity-Based Marketing</h4>
                  <p className="text-sm text-zinc-600 dark:text-zinc-400">Connect with your audience on a deeper level through shared values and experiences.</p>
                </div>
                <div className="bg-white dark:bg-zinc-800 p-4 rounded-lg shadow-md">
                  <h4 className="font-bold mb-2">Oneness-Centered Networking</h4>
                  <p className="text-sm text-zinc-600 dark:text-zinc-400">Build meaningful relationships that transcend traditional business boundaries.</p>
                </div>
                <div className="bg-white dark:bg-zinc-800 p-4 rounded-lg shadow-md">
                  <h4 className="font-bold mb-2">Creative Problem Solving</h4>
                  <p className="text-sm text-zinc-600 dark:text-zinc-400">Develop innovative solutions to complex challenges in your business and life.</p>
                </div>
                <div className="bg-white dark:bg-zinc-800 p-4 rounded-lg shadow-md">
                  <h4 className="font-bold mb-2">Psychological Sales Techniques</h4>
                  <p className="text-sm text-zinc-600 dark:text-zinc-400">Master the art of ethical persuasion to boost your sales and influence.</p>
                </div>
                <div className="bg-white dark:bg-zinc-800 p-4 rounded-lg shadow-md">
                  <h4 className="font-bold mb-2">Persuasive Copywriting Frameworks</h4>
                  <p className="text-sm text-zinc-600 dark:text-zinc-400">Craft compelling messages that drive action and results.</p>
                </div>
                <div className="bg-white dark:bg-zinc-800 p-4 rounded-lg shadow-md">
                  <h4 className="font-bold mb-2">Holistic Lifestyle Design</h4>
                  <p className="text-sm text-zinc-600 dark:text-zinc-400">Create a balanced, fulfilling life that integrates work, health, and personal growth.</p>
                </div>
                <div className="bg-white dark:bg-zinc-800 p-4 rounded-lg shadow-md">
                  <h4 className="font-bold mb-2">Internal Mastery Principles</h4>
                  <p className="text-sm text-zinc-600 dark:text-zinc-400">Optimize your health and focus for peak performance in all areas of life.</p>
                </div>
                <div className="bg-white dark:bg-zinc-800 p-4 rounded-lg shadow-md">
                  <h4 className="font-bold mb-2">Mindfulness Philosophy</h4>
                  <p className="text-sm text-zinc-600 dark:text-zinc-400">Cultivate deep work and meaning through present-moment awareness.</p>
                </div>
                <div className="bg-white dark:bg-zinc-800 p-4 rounded-lg shadow-md">
                  <h4 className="font-bold mb-2">Quantum Transmutation Rituals</h4>
                  <p className="text-sm text-zinc-600 dark:text-zinc-400">Accelerate your manifestation abilities through powerful energetic practices.</p>
                </div>
                <div className="bg-white dark:bg-zinc-800 p-4 rounded-lg shadow-md">
                  <h4 className="font-bold mb-2">Energetic Optimization</h4>
                  <p className="text-sm text-zinc-600 dark:text-zinc-400">Elevate your vibration and attract positive experiences and opportunities.</p>
                </div>
                <div className="bg-white dark:bg-zinc-800 p-4 rounded-lg shadow-md">
                  <h4 className="font-bold mb-2">Digital AI Automation</h4>
                  <p className="text-sm text-zinc-600 dark:text-zinc-400">Leverage cutting-edge tools to reduce your workload to just 2 hours per week.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-center mb-12">
              Transform Your Life Today
            </h2>
            <div className="grid gap-8 md:grid-cols-3">
              <div className="flex flex-col p-6 bg-white dark:bg-zinc-800 rounded-lg shadow-lg">
                <h3 className="text-2xl font-bold mb-4">Ebook/Audiobook</h3>
                <p className="text-zinc-600 dark:text-zinc-400 mb-4">Start your journey with our comprehensive guide to breaking free from the 9-5 grind.</p>
                <p className="text-3xl font-bold mb-6">$10</p>
                <Button className="mt-auto">Get Started</Button>
              </div>
              <div className="flex flex-col p-6 bg-white dark:bg-zinc-800 rounded-lg shadow-lg">
                <h3 className="text-2xl font-bold mb-4">Online Course</h3>
                <p className="text-zinc-600 dark:text-zinc-400 mb-4">Dive deeper with our interactive course, packed with practical strategies and exercises.</p>
                <p className="text-3xl font-bold mb-6">$100</p>
                <Button className="mt-auto">Enroll Now</Button>
              </div>
              <div className="flex flex-col p-6 bg-white dark:bg-zinc-800 rounded-lg shadow-lg">
                <h3 className="text-2xl font-bold mb-4">Personal 3-Month Program</h3>
                <p className="text-zinc-600 dark:text-zinc-400 mb-4">Experience transformative results with our personalized coaching and support.</p>
                <p className="text-3xl font-bold mb-6">$1000</p>
                <Button className="mt-auto">Apply Now</Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-zinc-500 dark:text-zinc-400">© 2023 Creator Consciousness. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Terms of Service
          </Link>
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  )
}


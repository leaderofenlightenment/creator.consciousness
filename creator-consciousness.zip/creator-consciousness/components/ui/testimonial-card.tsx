import { cn } from "@/lib/utils"
import { StarFilledIcon } from "@radix-ui/react-icons"
import Image from "next/image"

export interface TestimonialCardProps {
  name: string
  role: string
  description: React.ReactNode
  image: string
  className?: string
  [key: string]: any
}

export const TestimonialCard = ({
  description,
  name,
  image,
  role,
  className,
  ...props
}: TestimonialCardProps) => (
  <div
    className={cn(
      "flex w-80 shrink-0 cursor-pointer snap-center snap-always flex-col justify-between rounded-xl p-6 shadow-xl shadow-black/[0.1] lg:w-96",
      "border border-neutral-200 bg-white",
      "dark:bg-black dark:[border:1px_solid_rgba(255,255,255,.1)] dark:[box-shadow:0_-20px_80px_-20px_#ffffff1f_inset]",
      className,
    )}
    {...props}
  >
    <div className="flex items-center gap-4 mb-4">
      <Image
        src={image}
        alt={name}
        width={80}
        height={80}
        className="rounded-full object-cover"
      />
      <div>
        <p className="font-medium text-neutral-900 dark:text-neutral-100">{name}</p>
        <p className="text-sm text-neutral-600 dark:text-neutral-400">{role}</p>
      </div>
    </div>
    <div className="select-none font-normal text-neutral-700 dark:text-neutral-300 mb-4 text-sm">
      {description}
    </div>
    <div className="flex flex-row">
      <StarFilledIcon className="size-4 text-yellow-500" />
      <StarFilledIcon className="size-4 text-yellow-500" />
      <StarFilledIcon className="size-4 text-yellow-500" />
      <StarFilledIcon className="size-4 text-yellow-500" />
      <StarFilledIcon className="size-4 text-yellow-500" />
    </div>
  </div>
)

